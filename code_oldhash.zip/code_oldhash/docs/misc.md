# Changelog
## 0.1.2
Add web inference interface. Now can do quick demo/testing on trained model.
Fixed `wandb` being called when not enabled.

## 0.1.1
Add support for Weight and Bias logging

## 0.1.0
Initial release.